package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ClientEntity
import com.example.ui.components.AddTransactionBottomSheet
import com.example.ui.components.NotificationsBottomSheet
import com.example.ui.screens.ClientPortalScreen
import com.example.ui.screens.ClientsScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AccountingViewModel

data class NavTabItem(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val badgeCount: Int = 0
)

class MainActivity : ComponentActivity() {

    private val viewModel: AccountingViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(viewModel: AccountingViewModel) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val metrics by viewModel.financialMetrics.collectAsStateWithLifecycle()
    val transactions by viewModel.filteredTransactions.collectAsStateWithLifecycle()
    val allTransactionsList by viewModel.allTransactions.collectAsStateWithLifecycle()
    val breakdowns by viewModel.categoryBreakdown.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedFilter.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val clients by viewModel.allClients.collectAsStateWithLifecycle()
    val currentPortalClient by viewModel.currentPortalClient.collectAsStateWithLifecycle()
    val portalLetters by viewModel.portalClientLetters.collectAsStateWithLifecycle()
    val portalTransactions by viewModel.portalClientTransactions.collectAsStateWithLifecycle()
    val notifications by viewModel.allNotifications.collectAsStateWithLifecycle()
    val unreadNotifsCount by viewModel.unreadNotificationsCount.collectAsStateWithLifecycle()
    val unreadLettersCount by viewModel.unreadLettersCount.collectAsStateWithLifecycle()

    var showAddTransactionSheet by remember { mutableStateOf(false) }
    var showNotificationsSheet by remember { mutableStateOf(false) }

    val navTabs = listOf(
        NavTabItem("İcmal", Icons.Default.Dashboard, Icons.Outlined.Dashboard),
        NavTabItem("Hesabatlar", Icons.Default.BarChart, Icons.Outlined.BarChart),
        NavTabItem("Müştərilər", Icons.Default.People, Icons.Outlined.People),
        NavTabItem("Müştəri Portalı", Icons.Default.AccountCircle, Icons.Outlined.AccountCircle, badgeCount = unreadLettersCount)
    )

    if (showAddTransactionSheet) {
        AddTransactionBottomSheet(
            clients = clients,
            onDismiss = { showAddTransactionSheet = false },
            onAdd = { title, amount, type, category, clientId, clientName, invoiceNo, note ->
                viewModel.addTransaction(
                    title = title,
                    amount = amount,
                    type = type,
                    category = category,
                    clientId = clientId,
                    clientName = clientName,
                    invoiceNo = invoiceNo,
                    note = note
                )
            },
            onParseText = { text -> viewModel.parseQuickText(text) }
        )
    }

    if (showNotificationsSheet) {
        NotificationsBottomSheet(
            notifications = notifications,
            onDismiss = { showNotificationsSheet = false },
            onMarkRead = { id -> viewModel.markNotificationAsRead(id) },
            onMarkAllRead = { viewModel.markAllNotificationsAsRead() },
            onClearAll = { viewModel.clearAllNotifications() },
            onTriggerTaxReminder = { viewModel.triggerTaxDeadlineAlert() }
        )
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("main_bottom_nav")
            ) {
                navTabs.forEachIndexed { index, tab ->
                    val isSelected = currentTab == index
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.setTab(index) },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (tab.badgeCount > 0) {
                                        Badge(containerColor = ExpenseRed, contentColor = Color.White) {
                                            Text("${tab.badgeCount}")
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = tab.title,
                                    tint = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        label = {
                            Text(
                                text = tab.title,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 11.sp
                                )
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            indicatorColor = EmeraldPrimary.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_tab_$index")
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (currentTab) {
                0 -> DashboardScreen(
                    metrics = metrics,
                    transactions = transactions,
                    selectedFilter = selectedFilter,
                    searchQuery = searchQuery,
                    onFilterSelect = { viewModel.setDateFilter(it) },
                    onSearchChange = { viewModel.setSearchQuery(it) },
                    onOpenAddTransaction = { showAddTransactionSheet = true },
                    onDeleteTransaction = { viewModel.deleteTransaction(it) },
                    onOpenNotifications = { showNotificationsSheet = true },
                    unreadNotifCount = unreadNotifsCount,
                    onOpenPortal = { viewModel.setTab(3) }
                )
                1 -> ReportsScreen(
                    metrics = metrics,
                    breakdowns = breakdowns,
                    selectedFilter = selectedFilter,
                    onFilterSelect = { viewModel.setDateFilter(it) }
                )
                2 -> ClientsScreen(
                    clients = clients,
                    onAddClient = { name, company, voen, phone, email, status, pin, note ->
                        viewModel.addClient(name, company, voen, phone, email, status, pin, note)
                    },
                    onUpdateStatus = { client, newStatus ->
                        viewModel.updateClientStatus(client, newStatus)
                    },
                    onSendLetter = { clientId, clientName, title, message, category, isImportant ->
                        viewModel.sendLetter(clientId, clientName, title, message, category, isImportant)
                    },
                    onSelectClientForPortal = { clientId ->
                        viewModel.setPortalClientId(clientId)
                        viewModel.setTab(3)
                    }
                )
                3 -> ClientPortalScreen(
                    clients = clients,
                    currentClient = currentPortalClient,
                    letters = portalLetters,
                    transactions = portalTransactions,
                    onSelectClient = { viewModel.setPortalClientId(it) },
                    onMarkLetterRead = { viewModel.markLetterAsRead(it) },
                    onSendClientInquiry = { inquiry ->
                        viewModel.sendLetter(
                            clientId = currentPortalClient?.id,
                            clientName = currentPortalClient?.companyName ?: "Müştəri",
                            title = "Müştəri Sorğusu: ${currentPortalClient?.companyName}",
                            message = inquiry,
                            category = "Müştəri Müraciəti",
                            isImportant = false
                        )
                    }
                )
            }
        }
    }
}
