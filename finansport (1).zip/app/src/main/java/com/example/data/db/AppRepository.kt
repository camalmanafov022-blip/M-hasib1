package com.example.data.db

import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

class AppRepository(private val dao: AppDao) {

    // Transactions
    val allTransactions: Flow<List<TransactionEntity>> = dao.getAllTransactions()

    fun getTransactionsByClient(clientId: Long): Flow<List<TransactionEntity>> =
        dao.getTransactionsByClient(clientId)

    fun getTransactionsBetween(startTime: Long, endTime: Long): Flow<List<TransactionEntity>> =
        dao.getTransactionsBetween(startTime, endTime)

    suspend fun insertTransaction(transaction: TransactionEntity): Long =
        dao.insertTransaction(transaction)

    suspend fun updateTransaction(transaction: TransactionEntity) =
        dao.updateTransaction(transaction)

    suspend fun deleteTransaction(transaction: TransactionEntity) =
        dao.deleteTransaction(transaction)

    suspend fun deleteTransactionById(id: Long) =
        dao.deleteTransactionById(id)

    // Clients
    val allClients: Flow<List<ClientEntity>> = dao.getAllClients()

    suspend fun getClientById(id: Long): ClientEntity? =
        dao.getClientById(id)

    fun getClientFlowById(id: Long): Flow<ClientEntity?> =
        dao.getClientFlowById(id)

    suspend fun insertClient(client: ClientEntity): Long =
        dao.insertClient(client)

    suspend fun updateClient(client: ClientEntity) =
        dao.updateClient(client)

    suspend fun deleteClient(client: ClientEntity) =
        dao.deleteClient(client)

    // Letters
    val allLetters: Flow<List<LetterEntity>> = dao.getAllLetters()

    fun getLettersForClient(clientId: Long): Flow<List<LetterEntity>> =
        dao.getLettersForClient(clientId)

    suspend fun insertLetter(letter: LetterEntity): Long =
        dao.insertLetter(letter)

    suspend fun markLetterAsRead(letterId: Long) =
        dao.markLetterAsRead(letterId)

    suspend fun deleteLetter(letter: LetterEntity) =
        dao.deleteLetter(letter)

    // Notifications
    val allNotifications: Flow<List<NotificationEntity>> = dao.getAllNotifications()

    suspend fun insertNotification(notification: NotificationEntity): Long =
        dao.insertNotification(notification)

    suspend fun markNotificationAsRead(notifId: Long) =
        dao.markNotificationAsRead(notifId)

    suspend fun markAllNotificationsAsRead() =
        dao.markAllNotificationsAsRead()

    suspend fun deleteNotificationById(id: Long) =
        dao.deleteNotificationById(id)

    suspend fun clearAllNotifications() =
        dao.clearAllNotifications()
}
