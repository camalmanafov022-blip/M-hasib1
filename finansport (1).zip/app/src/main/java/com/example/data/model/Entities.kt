package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType {
    INCOME, // Gəlir
    EXPENSE // Xərc
}

enum class PaymentStatus {
    PAID,      // Ödənilib
    PENDING,   // Gözləmədə
    OVERDUE    // Gecikir
}

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val amount: Double,
    val type: TransactionType,
    val category: String,
    val timestamp: Long = System.currentTimeMillis(),
    val clientId: Long? = null,
    val clientName: String? = null,
    val invoiceNo: String = "",
    val paymentStatus: PaymentStatus = PaymentStatus.PAID,
    val note: String = ""
)

@Entity(tableName = "clients")
data class ClientEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val companyName: String,
    val voen: String, // VÖEN (Vergi Ödəyicisinin Eyniləşdirmə Nömrəsi)
    val phone: String,
    val email: String,
    val status: String = "Aktiv", // e.g., "Bəyannamə Hazırlanır", "Vergi Ödənişi Gözləyir", "Təsdiqləndi", "Auditdədir"
    val totalRevenue: Double = 0.0,
    val totalDebt: Double = 0.0,
    val contractDate: String = "01.01.2026",
    val pinCode: String = "1234",
    val notes: String = ""
)

@Entity(tableName = "letters")
data class LetterEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val clientId: Long? = null, // null if sent to all clients
    val clientName: String = "Bütün Müştərilər",
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isImportant: Boolean = false,
    val isRead: Boolean = false,
    val letterCategory: String = "Rəsmi Bildiriş", // e.g. "Vergi Xəbərdarlığı", "Hesabat Təsdiqi", "Faktura Aktı"
    val senderName: String = "Baş Mühasib (Nəzarət Şöbəsi)"
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val type: String = "TAX_ALERT", // "TAX_ALERT", "CLIENT_STATUS", "PAYMENT_DUE", "LETTER"
    val isRead: Boolean = false,
    val actionTarget: String = ""
)
