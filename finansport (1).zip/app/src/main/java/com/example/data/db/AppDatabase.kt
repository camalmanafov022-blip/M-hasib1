package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

@Database(
    entities = [
        TransactionEntity::class,
        ClientEntity::class,
        LetterEntity::class,
        NotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "muhasib_pro_database"
                )
                    .addCallback(AppDatabaseCallback(scope))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class AppDatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.appDao())
                    }
                }
            }

            private suspend fun populateInitialData(dao: AppDao) {
                val now = System.currentTimeMillis()
                val day = TimeUnit.DAYS.toMillis(1)

                // 1. Initial Clients
                val clients = listOf(
                    ClientEntity(
                        id = 1,
                        name = "Rəşad Əliyev",
                        companyName = "Baku Tech MMC",
                        voen = "1405892341",
                        phone = "+994 50 234 56 78",
                        email = "info@bakutech.az",
                        status = "Bəyannamə Təsdiqləndi",
                        totalRevenue = 18500.0,
                        totalDebt = 0.0,
                        contractDate = "15.01.2025",
                        pinCode = "1001",
                        notes = "İT xidmətləri və proqram təminatı satışı. ƏDV ödəyicisi."
                    ),
                    ClientEntity(
                        id = 2,
                        name = "Aygün Məmmədova",
                        companyName = "Xəzər Logistika",
                        voen = "2001489721",
                        phone = "+994 55 412 89 00",
                        email = "aygun@khazarlogistics.az",
                        status = "Vergi Ödənişi Gözləyir",
                        totalRevenue = 34200.0,
                        totalDebt = 684.0,
                        contractDate = "01.03.2025",
                        pinCode = "1002",
                        notes = "Yükdaşıma xidməti. Sadələşdirilmiş vergi 2%."
                    ),
                    ClientEntity(
                        id = 3,
                        name = "Kamran Qasımov",
                        companyName = "İnnovasiya Dizayn Studiyası",
                        voen = "1903421155",
                        phone = "+994 70 890 12 34",
                        email = "contact@innovadesign.az",
                        status = "Audit Hazırlanır",
                        totalRevenue = 9400.0,
                        totalDebt = 250.0,
                        contractDate = "10.06.2025",
                        pinCode = "1003",
                        notes = "Qrafik dizayn və marketinq. Fərdi Sahibkar (Gəlir vergisi)."
                    ),
                    ClientEntity(
                        id = 4,
                        name = "Nigar Həsənova",
                        companyName = "Caspian Trade Group",
                        voen = "2901147890",
                        phone = "+994 12 498 77 66",
                        email = "nigar@caspiantrade.az",
                        status = "DSMF Hesabatı Hazırdır",
                        totalRevenue = 52000.0,
                        totalDebt = 1200.0,
                        contractDate = "20.11.2024",
                        pinCode = "1004",
                        notes = "Topdansatış və idxal. ƏDV və Mənfəət vergisi."
                    )
                )
                dao.insertClients(clients)

                // 2. Initial Transactions
                val transactions = listOf(
                    TransactionEntity(
                        title = "Proqram Təminatı Satışı (Baku Tech)",
                        amount = 4500.0,
                        type = TransactionType.INCOME,
                        category = "Xidmət & Satış",
                        timestamp = now - (day * 1),
                        clientId = 1,
                        clientName = "Baku Tech MMC",
                        invoiceNo = "INV-2026-042",
                        paymentStatus = PaymentStatus.PAID,
                        note = "Aylıq ERP texniki dəstək haqqı"
                    ),
                    TransactionEntity(
                        title = "Logistika və Çatdırılma Gəliri",
                        amount = 6200.0,
                        type = TransactionType.INCOME,
                        category = "Xidmət & Satış",
                        timestamp = now - (day * 2),
                        clientId = 2,
                        clientName = "Xəzər Logistika",
                        invoiceNo = "INV-2026-041",
                        paymentStatus = PaymentStatus.PAID,
                        note = "Regionlararası yükdaşıma xidməti"
                    ),
                    TransactionEntity(
                        title = "Ofis İcarə Xərci (Nizami küç.)",
                        amount = 1800.0,
                        type = TransactionType.EXPENSE,
                        category = "Ofis & İcarə",
                        timestamp = now - (day * 3),
                        invoiceNo = "EXP-8891",
                        paymentStatus = PaymentStatus.PAID,
                        note = "Mərkəzi ofisin icarə haqqı və komendant xərcləri"
                    ),
                    TransactionEntity(
                        title = "Əməkhaqqı Fondu və Avanslar",
                        amount = 3200.0,
                        type = TransactionType.EXPENSE,
                        category = "Əməkhaqqı",
                        timestamp = now - (day * 4),
                        invoiceNo = "SAL-0226",
                        paymentStatus = PaymentStatus.PAID,
                        note = "İşçilərin aylıq rəsmi maaş ödənişləri"
                    ),
                    TransactionEntity(
                        title = "DSMF və İcbari Tibbi Sığorta",
                        amount = 960.0,
                        type = TransactionType.EXPENSE,
                        category = "Vergilər & DSMF",
                        timestamp = now - (day * 5),
                        invoiceNo = "TAX-5501",
                        paymentStatus = PaymentStatus.PAID,
                        note = "Dövlət Sosial Müdafiə Fondu ayırmaları"
                    ),
                    TransactionEntity(
                        title = "Brendinq Layihəsi (İnnovasiya Dizayn)",
                        amount = 2800.0,
                        type = TransactionType.INCOME,
                        category = "Konsaltinq",
                        timestamp = now - (day * 7),
                        clientId = 3,
                        clientName = "İnnovasiya Dizayn Studiyası",
                        invoiceNo = "INV-2026-039",
                        paymentStatus = PaymentStatus.PAID,
                        note = "UI/UX və brendinq xidməti 1-ci mərhələ"
                    ),
                    TransactionEntity(
                        title = "Server və Cloud Bulud Abunəliyi",
                        amount = 350.0,
                        type = TransactionType.EXPENSE,
                        category = "Avadanlıq & IT",
                        timestamp = now - (day * 9),
                        invoiceNo = "EXP-7721",
                        paymentStatus = PaymentStatus.PAID,
                        note = "Google Cloud & AWS server xidmətləri"
                    ),
                    TransactionEntity(
                        title = "Topdansatış Müqaviləsi (Caspian Trade)",
                        amount = 8900.0,
                        type = TransactionType.INCOME,
                        category = "Məhsul Satışı",
                        timestamp = now - (day * 12),
                        clientId = 4,
                        clientName = "Caspian Trade Group",
                        invoiceNo = "INV-2026-038",
                        paymentStatus = PaymentStatus.PAID,
                        note = "Partiya üzrə avans ödənişi"
                    ),
                    TransactionEntity(
                        title = "Kommunal Xərclər (İşıq, Qaz, İnternet)",
                        amount = 240.0,
                        type = TransactionType.EXPENSE,
                        category = "Kommunal",
                        timestamp = now - (day * 15),
                        invoiceNo = "EXP-1102",
                        paymentStatus = PaymentStatus.PAID,
                        note = "Ofis kommunal ödənişləri"
                    )
                )
                dao.insertTransactions(transactions)

                // 3. Initial Letters from Accountant to Clients
                val letters = listOf(
                    LetterEntity(
                        clientId = 2,
                        clientName = "Xəzər Logistika",
                        title = "1-ci Rüb Üzrə Sadələşdirilmiş Vergi Bəyannaməsi",
                        message = "Hörmətli Aygün xanım, 1-ci rüb üzrə 684.00 ₼ məbləğində vergi hesablamanız hazırdır. Ödənişi ayın 20-dək Dövlət Vergi Xidmətinin hesabına köçürməyiniz xahiş olunur. Ətraflı akt qoşmada təqdim edilir.",
                        timestamp = now - (day * 1),
                        isImportant = true,
                        isRead = false,
                        letterCategory = "Vergi Xəbərdarlığı"
                    ),
                    LetterEntity(
                        clientId = 1,
                        clientName = "Baku Tech MMC",
                        title = "Mart Ayı ƏDV Bəyannaməsi Uğurla Təsdiqləndi",
                        message = "Hörmətli Rəşad bəy, şirkətinizin mart ayı üzrə ƏDV və Mənfəət bəyannaməsi Vergi portalı (e-taxes.gov.az) vasitəsilə təqdim edildi və 'Qəbul Olundu' statusu aldı. Şəxsi kabinetinizdə heç bir borc qalmamışdır.",
                        timestamp = now - (day * 2),
                        isImportant = false,
                        isRead = true,
                        letterCategory = "Hesabat Təsdiqi"
                    ),
                    LetterEntity(
                        clientId = null,
                        clientName = "Bütün Müştərilər",
                        title = "Diqqət: Yeni Vergi Qanunvericiliyi və DSMF Qaydaları",
                        message = "Əziz müştərilər, 2026-cı il üçün qüvvəyə minən yeni elektron qaimə-faktura və sosial sığorta qaydaları ilə bağlı məlumat bülletenimiz hazırlanmışdır. Xahiş edirik daxil olan xərclərin qaimələrini ayın sonunadək mühasibatlığa göndərəsiniz.",
                        timestamp = now - (day * 3),
                        isImportant = true,
                        isRead = false,
                        letterCategory = "Rəsmi Bildiriş"
                    ),
                    LetterEntity(
                        clientId = 3,
                        clientName = "İnnovasiya Dizayn Studiyası",
                        title = "Bank Çıxarışı və Təhvil-Təslim Aktı Tələbi",
                        message = "Kamran bəy salam, fevral-mart ayları üzrə icra olunmuş layihələrin imzalı təhvil-təslim aktlarını və bank çıxarışını sistemə yükləməyiniz və ya mühasibimizə göndərməyiniz xahiş olunur.",
                        timestamp = now - (day * 5),
                        isImportant = false,
                        isRead = false,
                        letterCategory = "Faktura Aktı"
                    )
                )
                dao.insertLetters(letters)

                // 4. Initial Notifications
                val notifications = listOf(
                    NotificationEntity(
                        title = "⚠️ Vergi Ödənişi Vaxtı Yaxınlaşır!",
                        message = "Cari ayın 20-si son vergi ödəmə günüdür. Bütün bəyannamələr yoxlanılmalıdır.",
                        timestamp = now - (day * 0),
                        type = "TAX_ALERT",
                        isRead = false,
                        actionTarget = "REPORTS"
                    ),
                    NotificationEntity(
                        title = "📩 Yeni Mühasib Məktubu",
                        message = "Xəzər Logistika şirkətinə 1-ci rüb vergi bildirişi göndərildi.",
                        timestamp = now - (TimeUnit.HOURS.toMillis(4)),
                        type = "LETTER",
                        isRead = false,
                        actionTarget = "CLIENT_PORTAL"
                    ),
                    NotificationEntity(
                        title = "✅ Müştəri Statusu Yeniləndi",
                        message = "Baku Tech MMC şirkətinin ƏDV hesabatı təsdiqləndi.",
                        timestamp = now - (day * 2),
                        type = "CLIENT_STATUS",
                        isRead = true,
                        actionTarget = "CLIENTS"
                    ),
                    NotificationEntity(
                        title = "💰 Gözlənilən Ödəniş Bildirişi",
                        message = "Caspian Trade Group şirkətindən 1200 ₼ qalıq borc gözlənilir.",
                        timestamp = now - (day * 4),
                        type = "PAYMENT_DUE",
                        isRead = true,
                        actionTarget = "CLIENTS"
                    )
                )
                dao.insertNotifications(notifications)
            }
        }
    }
}
