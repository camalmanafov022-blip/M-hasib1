package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AccountingViewModel

val IncomeCategories = listOf("Xidmət & Satış", "Konsaltinq", "Məhsul Satışı", "İcarə Gəliri", "Digər Gəlir")
val ExpenseCategories = listOf("Əməkhaqqı", "Ofis & İcarə", "Vergilər & DSMF", "Kommunal", "Avadanlıq & IT", "Marketinq", "Ezamiyyət & Nəqliyyat", "Digər Xərc")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTransactionBottomSheet(
    clients: List<ClientEntity>,
    onDismiss: () -> Unit,
    onAdd: (title: String, amount: Double, type: TransactionType, category: String, clientId: Long?, clientName: String?, invoiceNo: String, note: String) -> Unit,
    onParseText: (String) -> com.example.ui.viewmodel.ParsedTransaction?
) {
    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var transactionType by remember { mutableStateOf(TransactionType.EXPENSE) }
    var category by remember { mutableStateOf("Ofis & İcarə") }
    var selectedClient by remember { mutableStateOf<ClientEntity?>(null) }
    var invoiceNo by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var smartInputText by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp)
                .padding(bottom = 32.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Yeni Əməliyyat Əlavə Et",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Bağla")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Smart Quick-AI / Keyword Auto Fill Box
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.AutoAwesome,
                            contentDescription = "Smart Auto",
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Ağıllı Avtomatik Doldurma",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = EmeraldPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = smartInputText,
                            onValueChange = { smartInputText = it },
                            placeholder = { Text("məs: 'Ofis mebeli 450 azn' və ya 'Satış 2500'", fontSize = 12.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("smart_input_field"),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val parsed = onParseText(smartInputText)
                                if (parsed != null) {
                                    title = parsed.title
                                    if (parsed.amount > 0) amountText = parsed.amount.toString()
                                    transactionType = parsed.type
                                    category = parsed.category
                                    smartInputText = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("apply_smart_button")
                        ) {
                            Text("Tətbiq et", fontSize = 12.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Type Toggle (Gəlir vs Xərc)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(4.dp)
            ) {
                Button(
                    onClick = {
                        transactionType = TransactionType.INCOME
                        category = IncomeCategories.first()
                    },
                    modifier = Modifier.weight(1f).testTag("type_income_btn"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (transactionType == TransactionType.INCOME) IncomeGreen else Color.Transparent,
                        contentColor = if (transactionType == TransactionType.INCOME) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    elevation = null
                ) {
                    Icon(Icons.Default.ArrowDownward, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Gəlir (Mədaxil)", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        transactionType = TransactionType.EXPENSE
                        category = ExpenseCategories.first()
                    },
                    modifier = Modifier.weight(1f).testTag("type_expense_btn"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (transactionType == TransactionType.EXPENSE) ExpenseRed else Color.Transparent,
                        contentColor = if (transactionType == TransactionType.EXPENSE) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    elevation = null
                ) {
                    Icon(Icons.Default.ArrowUpward, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Xərc (Məxaric)", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Title Field
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Əməliyyatın Təsviri") },
                placeholder = { Text("məs: Aylıq xidmət haqqı və ya İcarə") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tx_title_input"),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Amount Field
            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it },
                label = { Text("Məbləğ (₼ AZN)") },
                placeholder = { Text("0.00") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tx_amount_input"),
                leadingIcon = {
                    Text(
                        "₼",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = if (transactionType == TransactionType.INCOME) IncomeGreen else ExpenseRed
                    )
                },
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Category Chips
            Text(
                text = "Kateqoriya Seçin",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            val currentCategories = if (transactionType == TransactionType.INCOME) IncomeCategories else ExpenseCategories
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(currentCategories) { cat ->
                    FilterChip(
                        selected = (category == cat),
                        onClick = { category = cat },
                        label = { Text(cat, fontSize = 12.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Client Link (Optional)
            if (clients.isNotEmpty()) {
                Text(
                    text = "Müştəri ilə Əlaqələndir (İxtiyari)",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = (selectedClient == null),
                            onClick = { selectedClient = null },
                            label = { Text("Heç biri", fontSize = 12.sp) }
                        )
                    }
                    items(clients) { client ->
                        FilterChip(
                            selected = (selectedClient?.id == client.id),
                            onClick = { selectedClient = client },
                            label = { Text(client.companyName, fontSize = 12.sp) }
                        )
                    }
                }
            }

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = errorMessage ?: "",
                    color = ExpenseRed,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Submit Button
            Button(
                onClick = {
                    val amount = amountText.replace(',', '.').toDoubleOrNull()
                    if (title.isBlank()) {
                        errorMessage = "Zəhmət olmasa təsvir daxil edin"
                    } else if (amount == null || amount <= 0) {
                        errorMessage = "Zəhmət olmasa düzgün məbləğ daxil edin"
                    } else {
                        onAdd(
                            title,
                            amount,
                            transactionType,
                            category,
                            selectedClient?.id,
                            selectedClient?.companyName,
                            invoiceNo,
                            note
                        )
                        onDismiss()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_transaction_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Icon(Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Qeydə Al və Balansı Yenilə", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun AddClientDialog(
    onDismiss: () -> Unit,
    onAddClient: (name: String, company: String, voen: String, phone: String, email: String, status: String, pin: String, note: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var company by remember { mutableStateOf("") }
    var voen by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Bəyannamə Hazırlanır") }
    var pin by remember { mutableStateOf("1005") }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Yeni Müştəri Şirkəti Əlavə Et",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = company,
                    onValueChange = { company = it },
                    label = { Text("Şirkət / Müəssisə Adı *") },
                    placeholder = { Text("məs: Caspian Agro MMC") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("client_company_input")
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Məsul Şəxs / Direktor *") },
                    placeholder = { Text("məs: Samir Əliyev") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("client_name_input")
                )

                OutlinedTextField(
                    value = voen,
                    onValueChange = { voen = it },
                    label = { Text("VÖEN (10 rəqəmli) *") },
                    placeholder = { Text("1400XXXXXX") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("client_voen_input")
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Əlaqə Nömrəsi") },
                    placeholder = { Text("+994 50 000 00 00") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Elektron Poçt") },
                    placeholder = { Text("info@company.az") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (error != null) {
                    Text(text = error ?: "", color = ExpenseRed, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (company.isBlank() || name.isBlank() || voen.isBlank()) {
                        error = "Zəhmət olmasa ulduzlu (*) sahələri doldurun"
                    } else {
                        onAddClient(name, company, voen, phone, email, status, pin, note)
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                modifier = Modifier.testTag("submit_add_client")
            ) {
                Text("Müştərini Qeyd Et")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Ləğv et")
            }
        }
    )
}

@Composable
fun UpdateStatusDialog(
    client: ClientEntity,
    onDismiss: () -> Unit,
    onUpdateStatus: (String) -> Unit
) {
    val statuses = listOf(
        "Bəyannamə Təsdiqləndi",
        "Vergi Ödənişi Gözləyir",
        "Bəyannamə Hazırlanır",
        "Auditdədir",
        "DSMF Hesabatı Hazırdır",
        "Borc Bildirişi Göndərildi"
    )

    var selectedStatus by remember { mutableStateOf(client.status) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Müştəri Statusunu Yenilə",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "${client.companyName} (${client.name})",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = EmeraldPrimary
                )
                Spacer(modifier = Modifier.height(14.dp))

                statuses.forEach { st ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { selectedStatus = st }
                            .padding(vertical = 10.dp, horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = (selectedStatus == st),
                            onClick = { selectedStatus = st }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = st,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = if (selectedStatus == st) FontWeight.Bold else FontWeight.Normal
                            )
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onUpdateStatus(selectedStatus)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                modifier = Modifier.testTag("confirm_status_btn")
            ) {
                Text("Statusu Təsdiqlə")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Geri")
            }
        }
    )
}

@Composable
fun ComposeLetterDialog(
    clients: List<ClientEntity>,
    preselectedClientId: Long? = null,
    onDismiss: () -> Unit,
    onSend: (clientId: Long?, clientName: String, title: String, message: String, category: String, isImportant: Boolean) -> Unit
) {
    var selectedClient by remember {
        mutableStateOf(clients.find { it.id == preselectedClientId })
    }
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Vergi Xəbərdarlığı") }
    var isImportant by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    val categories = listOf("Vergi Xəbərdarlığı", "Rəsmi Bildiriş", "Hesabat Təsdiqi", "Faktura Aktı", "Audit Nəticəsi")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Mühasib Məktubu Göndər",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Ünvanlanan Müştəri:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    item {
                        FilterChip(
                            selected = (selectedClient == null),
                            onClick = { selectedClient = null },
                            label = { Text("Bütün Müştərilər", fontSize = 11.sp) }
                        )
                    }
                    items(clients) { c ->
                        FilterChip(
                            selected = (selectedClient?.id == c.id),
                            onClick = { selectedClient = c },
                            label = { Text(c.companyName, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Məktubun Mövzusu *") },
                    placeholder = { Text("məs: 1-ci Rüb Bəyannamə Xəbərdarlığı") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("letter_title_input")
                )

                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    label = { Text("Mətn / Rəsmi Bildiriş *") },
                    placeholder = { Text("Məktubun ətraflı mətnini yazın...") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth().testTag("letter_message_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = isImportant,
                        onCheckedChange = { isImportant = it }
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Təcili və Vacib Bildiriş kimi İşarələ",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                    )
                }

                if (error != null) {
                    Text(text = error ?: "", color = ExpenseRed, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank() || message.isBlank()) {
                        error = "Mövzu və mətni daxil edin"
                    } else {
                        onSend(
                            selectedClient?.id,
                            selectedClient?.companyName ?: "Bütün Müştərilər",
                            title,
                            message,
                            category,
                            isImportant
                        )
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                modifier = Modifier.testTag("send_letter_confirm")
            ) {
                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Məktubu Göndər")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Bağla")
            }
        }
    )
}

@Composable
fun ExportReportDialog(
    metrics: com.example.ui.viewmodel.FinancialMetrics,
    filterName: String,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Assessment, contentDescription = null, tint = EmeraldPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Rəsmi Maliyyə Hesabatı Çıxarışı", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "MÜHASİBAT VƏ VERGİ HESABATI",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = EmeraldPrimary
                        )
                        Text(
                            text = "Dövr: $filterName",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Divider(modifier = Modifier.padding(vertical = 8.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Ümumi Gəlir (Dövriyyə):", style = MaterialTheme.typography.bodySmall)
                            Text(AccountingViewModel.formatAzn(metrics.totalIncome), fontWeight = FontWeight.Bold, color = IncomeGreen)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Ümumi Xərclər:", style = MaterialTheme.typography.bodySmall)
                            Text(AccountingViewModel.formatAzn(metrics.totalExpense), fontWeight = FontWeight.Bold, color = ExpenseRed)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Xalis Mənfəət / Zərər:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                            Text(
                                AccountingViewModel.formatAzn(metrics.netProfit),
                                fontWeight = FontWeight.Bold,
                                color = if (metrics.netProfit >= 0) IncomeGreen else ExpenseRed
                            )
                        }
                        Divider(modifier = Modifier.padding(vertical = 8.dp))
                        Text(
                            text = "Təxmini Vergi və Sosial Öhdəliklər:",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("• Sadələşdirilmiş Vergi (2%):", style = MaterialTheme.typography.bodySmall)
                            Text(AccountingViewModel.formatAzn(metrics.simplifiedTax), style = MaterialTheme.typography.bodySmall)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("• DSMF və Tibbi Sığorta:", style = MaterialTheme.typography.bodySmall)
                            Text(AccountingViewModel.formatAzn(metrics.dsmfEstimate), style = MaterialTheme.typography.bodySmall)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("• Mənfəət Vergisi (20%):", style = MaterialTheme.typography.bodySmall)
                            Text(AccountingViewModel.formatAzn(metrics.profitTaxEstimate), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "✓ Bu sənəd rəsmi mühasibatlıq proqram təminatından avtomatik hasil edilmişdir.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Hesabatı Paylaş")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Bağla")
            }
        }
    )
}
