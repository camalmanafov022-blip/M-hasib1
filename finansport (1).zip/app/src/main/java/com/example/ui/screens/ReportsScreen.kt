package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CategoryDonutChart
import com.example.ui.components.ExportReportDialog
import com.example.ui.components.MonthlyBarChart
import com.example.ui.theme.*
import com.example.ui.viewmodel.AccountingViewModel
import com.example.ui.viewmodel.CategoryBreakdown
import com.example.ui.viewmodel.DateFilter
import com.example.ui.viewmodel.FinancialMetrics

@Composable
fun ReportsScreen(
    metrics: FinancialMetrics,
    breakdowns: List<CategoryBreakdown>,
    selectedFilter: DateFilter,
    onFilterSelect: (DateFilter) -> Unit
) {
    var showExportDialog by remember { mutableStateOf(false) }

    if (showExportDialog) {
        ExportReportDialog(
            metrics = metrics,
            filterName = selectedFilter.label,
            onDismiss = { showExportDialog = false }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 96.dp, top = 8.dp)
    ) {
        // 1. Header with Export Button
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Maliyyə Hesabatları",
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Gəlir, xərc analitikası və vergi hesablamaları",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Button(
                    onClick = { showExportDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("export_report_button")
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Çıxarış", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // 2. Period Filter Chips
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(DateFilter.values()) { filter ->
                    FilterChip(
                        selected = (selectedFilter == filter),
                        onClick = { onFilterSelect(filter) },
                        label = { Text(filter.label, fontWeight = if (selectedFilter == filter) FontWeight.Bold else FontWeight.Normal) },
                        shape = RoundedCornerShape(20.dp),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        // 3. Profit & Loss Summary Row Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricSummaryCard(
                    title = "Dövriyyə / Gəlir",
                    amount = metrics.totalIncome,
                    count = metrics.incomeCount,
                    isPositive = true,
                    modifier = Modifier.weight(1f)
                )
                MetricSummaryCard(
                    title = "Xərclər",
                    amount = metrics.totalExpense,
                    count = metrics.expenseCount,
                    isPositive = false,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 4. Monthly Incomes vs Expenses Bar Chart
        item {
            MonthlyBarChart(
                incomeAmount = metrics.totalIncome,
                expenseAmount = metrics.totalExpense
            )
        }

        // 5. Category Donut Chart Breakdown
        item {
            CategoryDonutChart(breakdowns = breakdowns)
        }

        // 6. Tax & Social Fund Calculator Card (Azərbaycan Qanunvericiliyi)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(GoldAccent.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Calculate,
                                contentDescription = null,
                                tint = GoldAccent,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Vergi və Sosial Öhdəliklər (Avtomatik)",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "AR Vergi Məcəlləsinə uyğun təxmini hesablamalar",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    TaxRowItem(
                        label = "Sadələşdirilmiş Vergi (2%):",
                        desc = "Ümumi daxilolmalardan 2% dərəcə ilə",
                        amount = metrics.simplifiedTax
                    )
                    Divider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.surfaceVariant)

                    TaxRowItem(
                        label = "DSMF və Tibbi Sığorta:",
                        desc = "Sosial sığorta və icbari tibbi sığorta fondu",
                        amount = metrics.dsmfEstimate
                    )
                    Divider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.surfaceVariant)

                    TaxRowItem(
                        label = "Mənfəət Vergisi (20%):",
                        desc = "Xalis mənfəətdən (gəlir - xərc) 20% dərəcə",
                        amount = metrics.profitTaxEstimate
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Ümumi Təxmini Öhdəlik:",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = AccountingViewModel.formatAzn(metrics.simplifiedTax + metrics.dsmfEstimate),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = GoldAccent
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricSummaryCard(
    title: String,
    amount: Double,
    count: Int,
    isPositive: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isPositive) IncomeGreen.copy(alpha = 0.08f) else ExpenseRed.copy(alpha = 0.08f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = AccountingViewModel.formatAzn(amount),
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = if (isPositive) IncomeGreen else ExpenseRed
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "$count əməliyyat",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun TaxRowItem(
    label: String,
    desc: String,
    amount: Double
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = desc,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Text(
            text = AccountingViewModel.formatAzn(amount),
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
