package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.db.AppRepository
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

enum class DateFilter(val label: String) {
    THIS_MONTH("Cari Ay"),
    LAST_MONTH("Keçən Ay"),
    THIS_QUARTER("Cari Rüb"),
    THIS_YEAR("Bu İl"),
    ALL_TIME("Hamısı")
}

data class FinancialMetrics(
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val netProfit: Double = 0.0,
    val simplifiedTax: Double = 0.0, // 2%
    val dsmfEstimate: Double = 0.0, // DSMF & Medical insurance
    val profitTaxEstimate: Double = 0.0, // 20% of net profit
    val incomeCount: Int = 0,
    val expenseCount: Int = 0
)

data class CategoryBreakdown(
    val category: String,
    val totalAmount: Double,
    val percentage: Float,
    val isExpense: Boolean
)

class AccountingViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AppRepository

    init {
        val db = AppDatabase.getDatabase(application, viewModelScope)
        repository = AppRepository(db.appDao())
    }

    // Active Date Filter
    private val _selectedFilter = MutableStateFlow(DateFilter.THIS_MONTH)
    val selectedFilter: StateFlow<DateFilter> = _selectedFilter.asStateFlow()

    // Active Tab in Navigation (0: Dashboard, 1: Reports, 2: Clients, 3: Client Portal)
    private val _currentTab = MutableStateFlow(0)
    val currentTab: StateFlow<Int> = _currentTab.asStateFlow()

    // Portal Selected Client ID (null means demo first client or picker)
    private val _portalClientId = MutableStateFlow<Long?>(1L)
    val portalClientId: StateFlow<Long?> = _portalClientId.asStateFlow()

    // Search query for transactions & clients
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // All streams from DB
    val allTransactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allClients: StateFlow<List<ClientEntity>> = repository.allClients
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLetters: StateFlow<List<LetterEntity>> = repository.allLetters
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allNotifications: StateFlow<List<NotificationEntity>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Unread counts
    val unreadNotificationsCount: StateFlow<Int> = allNotifications.map { list ->
        list.count { !it.isRead }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val unreadLettersCount: StateFlow<Int> = allLetters.map { list ->
        list.count { !it.isRead }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Filtered Transactions based on Date Filter
    val filteredTransactions: StateFlow<List<TransactionEntity>> = combine(
        allTransactions,
        _selectedFilter,
        _searchQuery
    ) { transactions, filter, query ->
        val (start, end) = getTimeRangeForFilter(filter)
        transactions.filter { tx ->
            val matchesTime = tx.timestamp in start..end
            val matchesQuery = if (query.isBlank()) true else {
                tx.title.contains(query, ignoreCase = true) ||
                        tx.category.contains(query, ignoreCase = true) ||
                        (tx.clientName?.contains(query, ignoreCase = true) == true) ||
                        tx.invoiceNo.contains(query, ignoreCase = true)
            }
            matchesTime && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Calculated Financial Metrics
    val financialMetrics: StateFlow<FinancialMetrics> = filteredTransactions.map { list ->
        var income = 0.0
        var expense = 0.0
        var incCount = 0
        var expCount = 0

        list.forEach { tx ->
            if (tx.type == TransactionType.INCOME) {
                income += tx.amount
                incCount++
            } else {
                expense += tx.amount
                expCount++
            }
        }

        val net = income - expense
        val simpTax = income * 0.02 // 2% simplified tax
        val dsmf = if (expense > 0) expense * 0.15 else income * 0.05
        val profTax = if (net > 0) net * 0.20 else 0.0

        FinancialMetrics(
            totalIncome = income,
            totalExpense = expense,
            netProfit = net,
            simplifiedTax = simpTax,
            dsmfEstimate = dsmf,
            profitTaxEstimate = profTax,
            incomeCount = incCount,
            expenseCount = expCount
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FinancialMetrics())

    // Category Breakdown for Reports
    val categoryBreakdown: StateFlow<List<CategoryBreakdown>> = filteredTransactions.map { list ->
        val expenseList = list.filter { it.type == TransactionType.EXPENSE }
        val totalExp = expenseList.sumOf { it.amount }
        if (totalExp == 0.0) emptyList()
        else {
            expenseList.groupBy { it.category }
                .map { (cat, txs) ->
                    val sum = txs.sumOf { it.amount }
                    CategoryBreakdown(
                        category = cat,
                        totalAmount = sum,
                        percentage = ((sum / totalExp) * 100).toFloat(),
                        isExpense = true
                    )
                }
                .sortedByDescending { it.totalAmount }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Client Portal Selected Client Data
    val currentPortalClient: StateFlow<ClientEntity?> = combine(
        allClients,
        _portalClientId
    ) { clients, id ->
        if (clients.isEmpty()) null
        else clients.find { it.id == id } ?: clients.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Client Specific Letters
    val portalClientLetters: StateFlow<List<LetterEntity>> = combine(
        allLetters,
        _portalClientId
    ) { letters, id ->
        letters.filter { it.clientId == null || it.clientId == id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Client Specific Transactions / Invoices
    val portalClientTransactions: StateFlow<List<TransactionEntity>> = combine(
        allTransactions,
        _portalClientId
    ) { txs, id ->
        txs.filter { it.clientId == id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- ACTIONS ---

    fun setTab(tab: Int) {
        _currentTab.value = tab
    }

    fun setDateFilter(filter: DateFilter) {
        _selectedFilter.value = filter
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setPortalClientId(id: Long) {
        _portalClientId.value = id
    }

    // Smart Auto-Category / Receipt Parser
    fun parseQuickText(input: String): ParsedTransaction? {
        val clean = input.trim()
        if (clean.isBlank()) return null

        // Extract amount (matches numbers e.g. 150, 45.50, 1200)
        val regex = Regex("""\b(\d+([.,]\d{1,2})?)\b""")
        val match = regex.find(clean)
        val amount = match?.value?.replace(',', '.')?.toDoubleOrNull() ?: 0.0

        val lower = clean.lowercase(Locale.ROOT)
        val isIncome = lower.contains("gəlir") || lower.contains("satış") || lower.contains("ödəniş") ||
                lower.contains("daxil") || lower.contains("maaş daxil") || lower.contains("avans") || lower.contains("mədaxil")

        val category = when {
            lower.contains("əməkhaqqı") || lower.contains("maaş") -> "Əməkhaqqı"
            lower.contains("icarə") || lower.contains("ofis") -> "Ofis & İcarə"
            lower.contains("vergi") || lower.contains("dsmf") || lower.contains("sadələşdirilmiş") -> "Vergilər & DSMF"
            lower.contains("işıq") || lower.contains("qaz") || lower.contains("su") || lower.contains("kommunal") || lower.contains("internet") -> "Kommunal"
            lower.contains("server") || lower.contains("avadanlıq") || lower.contains("kompüter") || lower.contains("texnika") -> "Avadanlıq & IT"
            lower.contains("reklam") || lower.contains("marketinq") || lower.contains("instagram") -> "Marketinq"
            lower.contains("satış") || lower.contains("xidmət") || lower.contains("müqavilə") -> "Xidmət & Satış"
            isIncome -> "Xidmət & Satış"
            else -> "Digər Xərc"
        }

        val type = if (isIncome) TransactionType.INCOME else TransactionType.EXPENSE
        return ParsedTransaction(
            title = clean.replace(regex, "").trim().ifEmpty { if (type == TransactionType.INCOME) "Gəlir Mədaxili" else "Cari Xərc" },
            amount = amount,
            type = type,
            category = category
        )
    }

    fun addTransaction(
        title: String,
        amount: Double,
        type: TransactionType,
        category: String,
        clientId: Long? = null,
        clientName: String? = null,
        invoiceNo: String = "",
        paymentStatus: PaymentStatus = PaymentStatus.PAID,
        note: String = ""
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val inv = invoiceNo.ifBlank { "INV-${SimpleDateFormat("yyyyMMdd-HHmm", Locale.getDefault()).format(Date())}" }
            val tx = TransactionEntity(
                title = title,
                amount = amount,
                type = type,
                category = category,
                timestamp = System.currentTimeMillis(),
                clientId = clientId,
                clientName = clientName,
                invoiceNo = inv,
                paymentStatus = paymentStatus,
                note = note
            )
            repository.insertTransaction(tx)

            // Also create a quick notification
            val typeStr = if (type == TransactionType.INCOME) "Gəlir Qeydə Alındı (+${formatAzn(amount)})" else "Xərc Qeydə Alındı (-${formatAzn(amount)})"
            repository.insertNotification(
                NotificationEntity(
                    title = typeStr,
                    message = "$title ($category) uğurla balansa daxil edildi.",
                    timestamp = System.currentTimeMillis(),
                    type = if (type == TransactionType.INCOME) "INCOME" else "EXPENSE",
                    actionTarget = "DASHBOARD"
                )
            )
        }
    }

    fun deleteTransaction(tx: TransactionEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteTransaction(tx)
        }
    }

    // Client Management
    fun addClient(
        name: String,
        companyName: String,
        voen: String,
        phone: String,
        email: String,
        status: String = "Aktiv",
        pinCode: String = "1234",
        notes: String = ""
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val client = ClientEntity(
                name = name,
                companyName = companyName,
                voen = voen,
                phone = phone,
                email = email,
                status = status,
                pinCode = pinCode,
                notes = notes,
                contractDate = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date())
            )
            val newId = repository.insertClient(client)

            repository.insertNotification(
                NotificationEntity(
                    title = "👤 Yeni Müştəri Əlavə Edildi",
                    message = "$companyName ($name) mühasibat bazasına daxil edildi.",
                    timestamp = System.currentTimeMillis(),
                    type = "CLIENT_STATUS",
                    actionTarget = "CLIENTS"
                )
            )
        }
    }

    fun updateClientStatus(client: ClientEntity, newStatus: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = client.copy(status = newStatus)
            repository.updateClient(updated)

            // Send notification to client & accountant
            repository.insertNotification(
                NotificationEntity(
                    title = "📌 Müştəri Statusu Dəyişdirildi",
                    message = "${client.companyName} üçün yeni status: '$newStatus'",
                    timestamp = System.currentTimeMillis(),
                    type = "CLIENT_STATUS",
                    actionTarget = "CLIENTS"
                )
            )

            // Also send an automated letter
            repository.insertLetter(
                LetterEntity(
                    clientId = client.id,
                    clientName = client.companyName,
                    title = "Status Yenilənməsi: $newStatus",
                    message = "Hörmətli ${client.name}, şirkətinizin cari mühasibat statusu '$newStatus' olaraq qeyd edilmişdir. Detallı məlumat üçün şəxsi kabinetinizə baxa bilərsiniz.",
                    timestamp = System.currentTimeMillis(),
                    isImportant = newStatus.contains("Vergi") || newStatus.contains("Borc"),
                    letterCategory = "Rəsmi Bildiriş"
                )
            )
        }
    }

    fun updateClientDebt(client: ClientEntity, newDebt: Double) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = client.copy(totalDebt = newDebt)
            repository.updateClient(updated)
        }
    }

    // Letter Management (Accountant -> Client)
    fun sendLetter(
        clientId: Long?,
        clientName: String,
        title: String,
        message: String,
        category: String,
        isImportant: Boolean
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val letter = LetterEntity(
                clientId = clientId,
                clientName = clientName,
                title = title,
                message = message,
                timestamp = System.currentTimeMillis(),
                isImportant = isImportant,
                letterCategory = category
            )
            repository.insertLetter(letter)

            repository.insertNotification(
                NotificationEntity(
                    title = if (isImportant) "🚨 Təcili Mühasib Məktubu!" else "✉️ Yeni Rəsmi Məktub",
                    message = "$clientName üçün '$title' göndərildi.",
                    timestamp = System.currentTimeMillis(),
                    type = "LETTER",
                    actionTarget = "CLIENT_PORTAL"
                )
            )
        }
    }

    fun markLetterAsRead(letterId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.markLetterAsRead(letterId)
        }
    }

    // Notifications
    fun markNotificationAsRead(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.markNotificationAsRead(id)
        }
    }

    fun markAllNotificationsAsRead() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.markAllNotificationsAsRead()
        }
    }

    fun clearAllNotifications() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearAllNotifications()
        }
    }

    fun triggerTaxDeadlineAlert() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertNotification(
                NotificationEntity(
                    title = "⏰ Rəsmi Vergi Bəyannaməsi Xatırlatması",
                    message = "Rüblük və aylıq vergi bəyannamələrinin son təqdimat tarixi yaxınlaşır. Müştərilərin statuslarını yoxlayın.",
                    timestamp = System.currentTimeMillis(),
                    type = "TAX_ALERT",
                    actionTarget = "REPORTS"
                )
            )
        }
    }

    // Utility Date Calculations
    private fun getTimeRangeForFilter(filter: DateFilter): Pair<Long, Long> {
        val calendar = Calendar.getInstance()
        val now = calendar.timeInMillis

        return when (filter) {
            DateFilter.THIS_MONTH -> {
                calendar.set(Calendar.DAY_OF_MONTH, 1)
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                calendar.set(Calendar.MILLISECOND, 0)
                val start = calendar.timeInMillis
                calendar.add(Calendar.MONTH, 1)
                val end = calendar.timeInMillis
                Pair(start, end)
            }
            DateFilter.LAST_MONTH -> {
                calendar.set(Calendar.DAY_OF_MONTH, 1)
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                calendar.set(Calendar.MILLISECOND, 0)
                val end = calendar.timeInMillis
                calendar.add(Calendar.MONTH, -1)
                val start = calendar.timeInMillis
                Pair(start, end)
            }
            DateFilter.THIS_QUARTER -> {
                val currentMonth = calendar.get(Calendar.MONTH)
                val quarterStartMonth = (currentMonth / 3) * 3
                calendar.set(Calendar.MONTH, quarterStartMonth)
                calendar.set(Calendar.DAY_OF_MONTH, 1)
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                calendar.set(Calendar.MILLISECOND, 0)
                val start = calendar.timeInMillis
                calendar.add(Calendar.MONTH, 3)
                val end = calendar.timeInMillis
                Pair(start, end)
            }
            DateFilter.THIS_YEAR -> {
                calendar.set(Calendar.DAY_OF_YEAR, 1)
                calendar.set(Calendar.HOUR_OF_DAY, 0)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                calendar.set(Calendar.MILLISECOND, 0)
                val start = calendar.timeInMillis
                calendar.add(Calendar.YEAR, 1)
                val end = calendar.timeInMillis
                Pair(start, end)
            }
            DateFilter.ALL_TIME -> {
                Pair(0L, Long.MAX_VALUE)
            }
        }
    }

    companion object {
        fun formatAzn(amount: Double): String {
            val formatter = NumberFormat.getNumberInstance(Locale.GERMANY)
            formatter.minimumFractionDigits = 2
            formatter.maximumFractionDigits = 2
            return "${formatter.format(amount)} ₼"
        }

        fun formatDate(timestamp: Long): String {
            val sdf = SimpleDateFormat("dd.MM.yyyy, HH:mm", Locale.getDefault())
            return sdf.format(Date(timestamp))
        }

        fun formatDateShort(timestamp: Long): String {
            val sdf = SimpleDateFormat("dd MMM, yyyy", Locale("az"))
            return sdf.format(Date(timestamp))
        }
    }
}

data class ParsedTransaction(
    val title: String,
    val amount: Double,
    val type: TransactionType,
    val category: String
)
