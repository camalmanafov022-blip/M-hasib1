package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Modern Luxury Emerald & Deep Slate Financial Palette
val EmeraldPrimary = Color(0xFF0F766E) // Rich Teal-Emerald
val EmeraldPrimaryDark = Color(0xFF14B8A6) // Light Teal for Dark theme
val EmeraldContainer = Color(0xFFCCFBF1)
val OnEmeraldContainer = Color(0xFF115E59)

val SlateNavyDark = Color(0xFF0F172A)
val SlateNavyCard = Color(0xFF1E293B)
val SlateNavySurface = Color(0xFF090D16)

val GoldAccent = Color(0xFFD97706)
val GoldAccentLight = Color(0xFFFBBF24)
val IncomeGreen = Color(0xFF10B981)
val ExpenseRed = Color(0xFFEF4444)
val PendingOrange = Color(0xFFF59E0B)
val InfoBlue = Color(0xFF3B82F6)

// Neutral tones
val SurfaceLight = Color(0xFFF8FAFC)
val SurfaceCardLight = Color(0xFFFFFFFF)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)

val SurfaceDark = Color(0xFF0F172A)
val SurfaceCardDark = Color(0xFF1E293B)
val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)

